# -*- coding: utf-8 -*-

"""Main module."""
from .config import config
from .task import KubernetesTask
